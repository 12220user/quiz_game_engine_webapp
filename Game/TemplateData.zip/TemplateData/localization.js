const localize = function(value) {
    return value;
}